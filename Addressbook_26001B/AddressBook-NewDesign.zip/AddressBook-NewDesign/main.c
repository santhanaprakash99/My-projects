#include <stdio.h>
#include "contact.h"

int main() 
{
				/* Name          : Santhanaprakash M
				 * Batch         : 26001B
				 * project       : AddressBook
				 * Description   : A modular command-line application built in C to manage personal contacts. 
				 *                 This project implements custom struct data types, 
				 *                 file I/O for data persistence, and input validation logic to ensure memory safety and data integrity
				 */
				int choice;
				AddressBook addressBook;
				initialize(&addressBook); // Initialize the address book

				do 
				{		printf("\n");
								printf("\nAddress Book Menu:\n");
								printf("1. Create contact\n");
								printf("2. Search contact\n");
								printf("3. Edit contact\n");
								printf("4. Delete contact\n");
								printf("5. List all contacts\n");
								printf("6. Save and Exit\n");		
								printf("7. Exit\n");
								printf("Enter your choice: ");
								scanf("%d", &choice);

								switch (choice) 
								{
												case 1:
																createContact(&addressBook);
																break;
												case 2:
																searchContact(&addressBook);
																break;
												case 3:
																editContact(&addressBook);
																break;
												case 4:
																deleteContact(&addressBook);
																break;
												case 5:          
																listContacts(&addressBook);
																break;
												case 6:
																printf("Saving and Exiting...\n");
																saveContactsToFile(&addressBook);
																break;
												case 7:
																printf("Exiting...\n");
																return 0;
												default:
																printf("Invalid choice. Please try again.\n");
								}
				} while (choice != 6);

				return 0;
}
